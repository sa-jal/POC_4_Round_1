package BASE_CLASSES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MyAccount_Chrome {
	WebDriver wb;
	WebDriverWait wt;

	public MyAccount_Chrome(WebDriver wb1)
	{
		wb=wb1;
	}
	public void launch_chrome_browser_and_url()
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		wb= new ChromeDriver();
		wb.get("http://automationpractice.com/index.php");
	}

	public void login(String email, String password)
	{	
		wt=  new WebDriverWait(wb, 10);
		wb.findElement(By.xpath("//*[@class='login']")).click();
		wb.findElement(By.xpath("//*[@id='email']")).sendKeys(email);
		wb.findElement(By.xpath("//*[@name='passwd']")).sendKeys(password);
		wb.findElement(By.xpath("//*[@id='SubmitLogin']")).click();
	}	
	
	public String verify_profile()
	{
		wt.until(ExpectedConditions.elementToBeClickable(wb.findElement(By.xpath("//a[@class='account']"))));
		String act_result = wb.findElement(By.xpath("//a[@class='account']")).getText();
		return act_result;
	}
	public void go_to_home()
	{
		wb.findElement(By.xpath("//*[@class='home']")).click();
	}
	
	public void add_product_1()
	{
		Actions actns=new Actions(wb);
		WebElement we = wb.findElement(By.xpath("//*[@id='homefeatured']/li[1]/div/div[1]/div"));
		Action act = actns.moveToElement(we).build();
		act.perform();
		wb.findElement(By.xpath("//*[@id='homefeatured']/li[1]/div/div[2]/div[2]/a[1]")).click();
		wt.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@class='continue btn btn-default button exclusive-medium']")));
		wb.findElement(By.xpath("//*[@class='continue btn btn-default button exclusive-medium']")).click();
	}
	
	public void add_product_2()
	{
		Actions actns=new Actions(wb);
		WebElement we = wb.findElement(By.xpath("//*[@id='homefeatured']/li[3]/div/div[1]/div"));
		Action act = actns.moveToElement(we).build();
		act.perform();
		wb.findElement(By.xpath("//*[@id='homefeatured']/li[3]/div/div[2]/div[2]/a[1]")).click();
		wt.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@title='Close window']")));
		wb.findElement(By.xpath("//*[@title='Close window']")).click();
	}
	
	public void go_to_cart() {
		wt.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@title='View my shopping cart']")));
		wb.findElement(By.xpath("//a[@title='View my shopping cart']")).click();
	}
	
	public void increase_quantity_of_2()
	{
		wb.findElement(By.xpath("//*[@id='product_3_13_0_200704']/td[5]/div/a[2]")).click();
	}
	
	public String verify_product_1()
	{
		wt.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath("//*[contains(text(),'Faded Short Sleeve T-shirts')]"),"Faded"));
		String act_result=wb.findElement(By.xpath("//*[contains(text(),'Faded Short Sleeve T-shirts')]")).getText();
		return act_result;
	}
	
	public String verify_product_2()
	{
		wt.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath("//*[@id='product_3_13_0_200704']/td[2]/p"),"Printed"));
		String act_res = wb.findElement(By.xpath("//*[@id='product_3_13_0_200704']/td[2]/p")).getText();
		return act_res;
	}
	
	public double verify_product_1_unitprice()
	{
		String temp;
		double act_result;
		temp =wb.findElement(By.xpath("//*[@id='product_1_1_0_200704']/td[4]/span/span")).getText();
		temp=temp.substring(1,temp.length());
		act_result=Double.parseDouble(temp);
		return act_result;
	}
	
	public double verify_product_2_unitprice()
	{
		String temp;
		double act_result;
		temp =wb.findElement(By.xpath("//*[@id='product_3_13_0_200704']/td[4]/span/span")).getText();
		temp=temp.substring(1,temp.length());
		act_result=Double.parseDouble(temp);
		return act_result;
	}
	
	public double verify_product_1_total()
	{
		String temp;
		double act_result;
		temp =wb.findElement(By.xpath("//*[@id='product_price_1_1_200704']")).getText();
		temp=temp.substring(1,temp.length());
		act_result=Double.parseDouble(temp);
		return act_result;
	}
	public double verify_product_2_total()
	{
		String temp;
		double act_result;
		wt.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath("//*[@id='total_product_price_3_13_200704']"), "52.00"));
		temp =wb.findElement(By.xpath("//*[@id='total_product_price_3_13_200704']")).getText();
		temp=temp.substring(1,temp.length());
		act_result=Double.parseDouble(temp);
		return act_result;
	}
	
	public double verify_total()
	{
		double act_res,shipping=2;
		act_res=16.51+(26.00*2);
		act_res+=shipping;
		return act_res;
	}
}
