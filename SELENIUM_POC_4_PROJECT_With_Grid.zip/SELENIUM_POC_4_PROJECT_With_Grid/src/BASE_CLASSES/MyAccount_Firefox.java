package BASE_CLASSES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MyAccount_Firefox {
	WebDriver wb;
	WebDriverWait wt;
		
	public MyAccount_Firefox(WebDriver wb)
	{
		this.wb=wb;
	}
	
	public void launch_firefox_browser_and_url()
	{
		System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
		wb= new FirefoxDriver();
		wb.get("http://automationpractice.com/index.php");
	}

	public void login(String email, String password)
	{	
		wt=  new WebDriverWait(wb, 10);
		wb.findElement(By.xpath("//*[@class='login']")).click();
		wb.findElement(By.xpath("//*[@id='email']")).sendKeys(email);
		wb.findElement(By.xpath("//*[@name='passwd']")).sendKeys(password);
		wb.findElement(By.xpath("//*[@id='SubmitLogin']")).click();
	}	
	
	public String verify_profile()
	{
		wt.until(ExpectedConditions.elementToBeClickable(wb.findElement(By.xpath("//a[@class='account']"))));
		String act_result = wb.findElement(By.xpath("//a[@class='account']")).getText();
		return act_result;
	}

	public void go_to_home()
	{
		wb.findElement(By.xpath("//*[@class='home']")).click();
	}

	public void add_product_1()
	{
		wb.findElement(By.xpath("/html/body/div/div[2]/div/div[2]/div/div[1]/ul[1]/li[1]/div/div[1]/div")).click();
		wb.findElement(By.xpath("/html/body/div/div[2]/div/div[3]/div/div/div/div[4]/form/div/div[3]/div[1]/p/button")).click();
		wt.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[4]/div[1]/div[2]/div[4]/span")));
		wb.findElement(By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[4]/div[1]/div[2]/div[4]/span")).click();
		wb.findElement(By.xpath("/html/body/div/div[2]/div/div[1]/a[1]")).click();
	}
	
	public void add_product_2()
	{
		wb.findElement(By.xpath("/html/body/div/div[2]/div/div[2]/div/div[1]/ul[1]/li[3]/div/div[2]/h5/a")).click();
		wb.findElement(By.xpath("/html/body/div/div[2]/div/div[3]/div/div/div/div[4]/form/div/div[3]/div[1]/p/button")).click();
		wt.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[4]/div[1]/div[1]/span")));
		wb.findElement(By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[4]/div[1]/div[1]/span")).click();
		wb.findElement(By.xpath("/html/body/div/div[2]/div/div[1]/a[1]")).click();
	}
	
	public void go_to_cart() {
		wt.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[3]/div/a")));
		wb.findElement(By.xpath("/html/body/div/div[1]/header/div[3]/div/div/div[3]/div/a")).click();
	}
	
	public void increase_quantity_of_2()
	{
		wb.findElement(By.xpath("//*[@id=\"cart_quantity_up_3_13_0_200704\"]")).click();
	}
	
	public String verify_product_1()
	{
		wt.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath("/html/body/div/div[2]/div/div[3]/div/div[2]/table/tbody/tr[1]/td[2]/p/a"),"Faded"));
		String act_result=wb.findElement(By.xpath("/html/body/div/div[2]/div/div[3]/div/div[2]/table/tbody/tr[1]/td[2]/p/a")).getText();
		return act_result;
	}
	
	public String verify_product_2()
	{
		wt.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath("/html/body/div/div[2]/div/div[3]/div/div[2]/table/tbody/tr[2]/td[2]/p/a"),"Printed"));
		String act_res = wb.findElement(By.xpath("/html/body/div/div[2]/div/div[3]/div/div[2]/table/tbody/tr[2]/td[2]/p/a")).getText();
		return act_res;
	}
	
	public double verify_product_1_unitprice()
	{
		String temp;
		double act_result;
		temp =wb.findElement(By.xpath("/html/body/div/div[2]/div/div[3]/div/div[2]/table/tbody/tr[1]/td[4]/span/span")).getText();
		temp=temp.substring(1,temp.length());
		act_result=Double.parseDouble(temp);
		return act_result;
	}
	
	public double verify_product_2_unitprice()
	{
		String temp;
		double act_result;
		temp =wb.findElement(By.xpath("/html/body/div/div[2]/div/div[3]/div/div[2]/table/tbody/tr[2]/td[4]/span/span")).getText();
		temp=temp.substring(1,temp.length());
		act_result=Double.parseDouble(temp);
		return act_result;
	}
	
	public double verify_product_1_total()
	{
		String temp;
		double act_result;
		temp =wb.findElement(By.xpath("//*[@id=\"total_product_price_1_1_200704\"]")).getText();
		temp=temp.substring(1,temp.length());
		act_result=Double.parseDouble(temp);
		return act_result;
	}
	public double verify_product_2_total()
	{
		String temp;
		double act_result;
		wt.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath("//*[@id=\"total_product_price_3_13_200704\"]"), "52.00"));
		temp =wb.findElement(By.xpath("//*[@id=\"total_product_price_3_13_200704\"]")).getText();
		temp=temp.substring(1,temp.length());
		act_result=Double.parseDouble(temp);
		return act_result;
	}
	
	public double verify_total()
	{
		String temp;
		double act_result;
		temp = wb.findElement(By.xpath("//*[@id=\"total_price\"]")).getText();
		temp=temp.substring(1,temp.length());
		act_result=Double.parseDouble(temp);
		return act_result;
	}
	
}
